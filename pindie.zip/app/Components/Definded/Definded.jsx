import Styles from '../../games/[id]/Game.module.css'

export default function Definded() {
    return(
        <section className={Styles['game']}>
            <p>Такой игры не существует 😢</p>
        </section>
    )
}